import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class SimpleSudokuSolver extends JFrame {
    private static final int SIZE = 9;
    private JTextField[][] cells = new JTextField[SIZE][SIZE];
    private int[][] board = new int[SIZE][SIZE];
    private JButton easyButton, mediumButton, hardButton, solveButton;

    public SimpleSudokuSolver() {
        setTitle("Sudoku Solver");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // Center the frame

        JPanel boardPanel = new JPanel(new GridLayout(SIZE, SIZE));
        boardPanel.setBackground(Color.WHITE); // Set board background to white
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                cells[i][j] = new JTextField();
                cells[i][j].setHorizontalAlignment(JTextField.CENTER);
                cells[i][j].setFont(new Font("Arial", Font.BOLD, 20));
                cells[i][j].setForeground(Color.GREEN); // Set text color to green
                boardPanel.add(cells[i][j]);
            }
        }

        JPanel controlPanel = new JPanel();
        easyButton = new JButton("Easy");
        mediumButton = new JButton("Medium");
        hardButton = new JButton("Hard");
        solveButton = new JButton("Solve Puzzle");

        controlPanel.add(easyButton);
        controlPanel.add(mediumButton);
        controlPanel.add(hardButton);
        controlPanel.add(solveButton);

        add(boardPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        easyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePuzzle("easy");
                displayBoard();
            }
        });

        mediumButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePuzzle("medium");
                displayBoard();
            }
        });

        hardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePuzzle("hard");
                displayBoard();
            }
        });

        solveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (solve(board)) {
                    displayBoard();
                } else {
                    JOptionPane.showMessageDialog(null, "No solution exists for the given Sudoku puzzle.");
                }
            }
        });
    }

    private void displayBoard() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == 0) {
                    cells[i][j].setText("");
                } else {
                    cells[i][j].setText(String.valueOf(board[i][j]));
                    cells[i][j].setEditable(false);  // Make pre-filled cells non-editable
                }
            }
        }
    }

    private void generatePuzzle(String level) {
        resetBoard();
        solve(board); // Generate a fully solved board
        Random random = new Random();
        int removals;

        switch (level.toLowerCase()) {
            case "easy":
                removals = random.nextInt(6) + 35;  // Between 35 and 40
                break;
            case "medium":
                removals = random.nextInt(6) + 41;  // Between 41 and 46
                break;
            case "hard":
                removals = random.nextInt(6) + 47;  // Between 47 and 52
                break;
            default:
                removals = random.nextInt(21) + 35;
                break;
        }

        while (removals > 0) {
            int row = random.nextInt(SIZE);
            int col = random.nextInt(SIZE);
            if (board[row][col] != 0) {
                board[row][col] = 0;
                removals--;
            }
        }
    }

    private void resetBoard() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                board[i][j] = 0;
                cells[i][j].setEditable(true);  // Make all cells editable initially
                cells[i][j].setText("");        // Clear the text
            }
        }
    }

    private boolean solve(int[][] board) {
        int[] empty = findEmpty(board);
        if (empty == null) {
            return true; // No empty cells, puzzle solved
        }

        int row = empty[0];
        int col = empty[1];

        for (int num = 1; num <= SIZE; num++) {
            if (isValid(board, num, row, col)) {
                board[row][col] = num;
                if (solve(board)) {
                    return true;
                }
                board[row][col] = 0; // Backtrack
            }
        }
        return false;
    }

    private int[] findEmpty(int[][] board) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == 0) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    private boolean isValid(int[][] board, int num, int row, int col) {
        for (int i = 0; i < SIZE; i++) {
            if (board[row][i] == num || board[i][col] == num) {
                return false;
            }
        }

        int boxRowStart = row - row % 3;
        int boxColStart = col - col % 3;

        for (int i = boxRowStart; i < boxRowStart + 3; i++) {
            for (int j = boxColStart; j < boxColStart + 3; j++) {
                if (board[i][j] == num) {
                    return false;
                }
            }
        }

        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SimpleSudokuSolver().setVisible(true);
            }
        });
    }
}
